package com.lkf.services;
import javax.annotation.Resource;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.lkf.pojo.User;
import com.lkf.service.impl.UserServiceiml;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import us.codecraft.webmagic.model.annotation.TargetUrl;

//@RunWith(SpringJUnit4ClassRunner.class)     //表示继承了SpringJUnit4ClassRunner类
//@ContextConfiguration(locations = {"classpath:spring-mvc.xml","classpath:spring-mybatis.xml"})
@Service
public class Ajax {
    @Autowired
    private IUserService iUserService;

    public String  judge(String username)
    {
                //
                User user=this.iUserService.getUserById(username);
                if(user==null)
                {
                    System.out.println("no error!");
                   return "该用户名不存在！";
                }
                else
                {
                    return "";
                }
            }
//    @Test
//    public void  judge()
//    {
//        //
//        String username = "haha";
//        User user=this.iUserService.getUserById(username);
//        if(user==null)
//        {
//            System.out.println("no error!");
//         //   return "该用户名不存在！";
//        }
//        else
//        {
//          //  return "";
//        }
//    }
}
