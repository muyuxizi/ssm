package com.lkf.services;
import com.lkf.pojo.*;
public interface IUserService {
    public User getUserById(String username);
}
