package com.lkf.controller;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import com.lkf.pojo.*;
import com.lkf.services.IUserService;
import org.apache.ibatis.jdbc.Null;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;
import java.io.PrintWriter;

@Controller
//@RequestMapping(value="/index.jsp")
public class UserController {
    @Resource
    private IUserService iUserService;
    private String message;
    @RequestMapping(value="/land.action")
    public String toIndex(HttpServletRequest request, HttpServletResponse response,Model model,ModelMap modelmap)throws ServletException, IOException {
        //String = Integer.parseInt(request.getParameter("id"));
       // User user = this.iUserService.getUserById(userId);
     //   model.addAttribute("user", user);
        System.out.println(iUserService);
        String username=request.getParameter("form-username");
        String password=request.getParameter("form-password");
        User user=this.iUserService.getUserById(username);
        if(user==null)
        {

          /*  request.setContentType("text/html; charset=gbk");
            PrintWriter out = response.getWriter();
            out.println("<script language='javascript'>");
            out.println("alert('账号不存在！');");
            out.println("history.back();");
            out.print("</script>");*/
            message="账号不存在！";
            modelmap.addAttribute("Message",message);
            return "index";
        }
        else {
        if(user.getPassword().equals(password)==true)
        {
            System.out.println("yes");
            model.addAttribute("user",user);
            return "main";
        }
        else
        {
            message="密码错误！";
            modelmap.addAttribute("Message",message);
            return "index";
        }
        }
    }
}

