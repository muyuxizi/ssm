package com.lkf.service.impl;

import com.lkf.dao.UserMapper;
import com.lkf.pojo.User;
import com.lkf.services.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class UserServiceiml implements IUserService {
    @Resource
    private UserMapper userMapper;
    @Override
    public User getUserById(String username) {
        // TODO Auto-generated method stub
            return this.userMapper.selectByPrimaryKey(username);
    }
}
